
CODE For the communication

Visualization of generalized mean estimators using auxiliary information in survey sampling, Communications in Statistics - Theory and Methods.
Received 16 Nov 2018, Accepted 25 Mar 2019, Published online: 31 May 2019
https://doi.org/10.1080/03610926.2019.1601224

DATA

Diart.RData for i=1,2,3,4,6,8 are new datasets generated as explained in the paper.


AUTHOR

Rodolphe Priam

CONTACT
rpriam@gmail.com



